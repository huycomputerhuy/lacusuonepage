<div class="col-md-3">
	<div class="right-content" >
		<?php
		if( is_active_sidebar( 'sidebar-1' ) )
		{
			dynamic_sidebar( 'sidebar-1' );
		}
		?>
	</div>
</div>