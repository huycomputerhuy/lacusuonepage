<div class="quick-alo-phone quick-alo-green quick-alo-show" id="quick-alo-phoneIcon" style="right: 10px; top: 20%;">
    <a class="quick-alo-facebook" target="_blank" href="https://www.fb.com/luoiantoan.vn" title="<?php echo get_theme_mod("lacusu_massgage_alo") ?>">
        <div class="quick-alo-ph-circle"></div>
        <div class="quick-alo-ph-circle-fill"></div>
        <div class="quick-alo-ph-img-circle"></div>
    </a>
    <a class="quick-alo-phone-call"  href="tel:<?php echo get_theme_mod("lacusu_phone_num_alo")?>" title="<?php echo get_theme_mod("lacusu_massgage_alo") ?>">
        <div class="quick-alo-ph-circle"></div>
        <div class="quick-alo-ph-circle-fill"></div>
        <div class="quick-alo-ph-img-circle"></div>
    </a>

</div>
